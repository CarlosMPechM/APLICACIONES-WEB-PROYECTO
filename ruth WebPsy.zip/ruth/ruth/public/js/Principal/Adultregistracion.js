document.addEventListener('DOMContentLoaded', function() {
    // Obtener el parámetro userId de la URL y establecerlo en el campo oculto
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('userId');
    document.getElementById('userId').value = userId;

    var form = document.getElementById('adultosregis');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        var formData = new FormData(form);
        var data = {};
        formData.forEach((value, key) => data[key] = value);

        fetch('/api/registro-adulto', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                // Si la respuesta no es 'ok', lanza un error
                return response.text().then(text => { throw new Error(text) });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Mostrar mensaje de éxito
                alert('Datos del Tutor registrados correctamente');
                // Redirigir a la página de inicio de sesión
                window.location.href = '/Login';
            } else {
                alert('Error registrando datos del Tutor');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ocurrió un error al registrar los datos del tutor. Por favor, intenta nuevamente.');
        });
    });
});
